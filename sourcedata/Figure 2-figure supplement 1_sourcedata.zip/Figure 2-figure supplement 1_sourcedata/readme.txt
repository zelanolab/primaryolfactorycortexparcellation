ROI drawn independently by one of the co-authors 
    Manual_Segmentation_v2_1mm.nii.gz
    Manual_Segmentation_v2_2mm.nii.gz

Parcellation result of the ROI
    Parcellation_v2_1mm.nii.gz
    Parcellation_v2_1mm.nii.gz




Parcellation result of the indepedent dataset (53 subjects)
    TN_Left_Parcellation_2mm.nii.gz
    TN_Right_Parcellation_2mm.nii.gz