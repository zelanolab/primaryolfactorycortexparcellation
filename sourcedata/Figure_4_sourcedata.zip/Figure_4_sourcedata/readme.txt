
unique_pos_*.nii.gz: thresholded (0.999) *_corrp_stats images that indicate unique connection to each subregion.

Aon/
Tub/
PirF/
PirT/
	Postive (pos_OneSampT*.nii.gz) and negative (neg_OneSampT*.nii.gz) correlation permutation test results.

	Resol1mm/ 
		pos_OneSampT_tstat1_1mm_threshold.nii.gz: thresholded (unique to each subregion) tstat image at 1mm resolution.
		pos_OneSampT_tstat1_1mm.nii.gz: tstat image at 1mm resolution.
		*.mgh: thresholded tstat images interpolated to surface (Freesurfer's cvs_avg35_inMNI152)


Figure_4_reg2fs.dat: transformation matrix from FSL voxel -> Freesufrer surface (cvs_avg35_inMNI152)


See plot_results.m for how to prepare figures from raw stats images.



