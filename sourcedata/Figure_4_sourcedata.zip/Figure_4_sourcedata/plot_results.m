%% 
% Unique and common connections
threshold = 0.999;

fcdir = '~/Documents/RestfMRI/SourceData/Figure_4_sourcedata';
stats = { 'pos_OneSampT_tfce_corrp_tstat1.nii.gz'};
stats_abbrev = {'pos'};
roinames = { 'Aon', 'PirF', 'PirT', 'Tub'};
roi_abbrev = { 'Aon', 'PirF', 'PirT', 'Tub'};

savedir = fullfile( fcdir, 'Stats');
if ~exist( savedir, 'dir')
    mkdir( savedir);
end

nbrois = length( roinames);
vol = cell( nbrois, length( stats));
for k = 1 : nbrois
    for stats_ind = 1 : length( stats)
        vol{ k, stats_ind} = MRIread( fullfile( fcdir, roinames{ k}, stats{ stats_ind}));
        vol{ k, stats_ind}.vol = double( vol{ k, stats_ind}.vol > threshold);
    end
end

stats_mask = cell( 1, length( stats));
for stats_ind = 1 : length( stats)
    tmp = cellfun( @(x) x.vol, vol(:, stats_ind), 'UniformOutput', false);
    tmp = cat( 4, tmp{:}) > 0;
    stats_mask{ 1, stats_ind} = sum( tmp, 4);
end

for k = 1 : nbrois
    C = nchoosek( 1:nbrois, k);    
    for x = 1 : size( C, 1)
        for stats_ind = 1 : length( stats)
            overlap = vol( C(x, :), stats_ind);
            overlap = cellfun( @(x) x.vol, overlap, 'UniformOutput', false);
            overlap = cat( 4, overlap{:});
            overlap = double( sum( overlap, 4) > 0);
            
            overlap = overlap .* ( stats_mask{ 1, stats_ind} == k);
            
            if any( overlap(:))
                tmp_name = [];
                for tmp_idx = 1 : k
                    if tmp_idx == 1
                        tmp_name = roi_abbrev{ C( x, tmp_idx)};
                    else
                        tmp_name = [tmp_name, '_', roi_abbrev{ C( x, tmp_idx)}];
                    end
                end

                % nb of clusters, 
                name = [stats_abbrev{stats_ind}, '_Clust_', num2str( k), '_', tmp_name];
                fprintf( '%s\n', name);

                tmp = vol{ 1};
                tmp.vol = overlap;
                MRIwrite( tmp, fullfile( savedir, [name, '.nii.gz']), 'float');
            end 
            
        end 
    end
end

% t value maps of unique connections
tstat = 'pos_OneSampT_tstat1.nii.gz';
mask_prefix = 'pos_Clust_1_';
prefix = 'pos_Clust_1_tstat_';
for k = 1 : nbrois
    tmap = MRIread( fullfile( fcdir, roinames{ k}, tstat));
    
    maskfile = fullfile( savedir, [mask_prefix, roinames{ k}]);
    mask = MRIread( maskfile);
    
    tmap.vol = tmap.vol .* mask.vol;
    MRIwrite( tmap, fullfile( savedir, [prefix, roinames{k}, '.nii.gz']), 'float');
end


% To resample the images to 1mm and project to surface, use plot_result.sh

