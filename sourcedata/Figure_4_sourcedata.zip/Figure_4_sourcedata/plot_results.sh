#!/usr/bin/env bash


# a copy of Freesufer's cvs_avg35_inMNI152 subject
export SUBJECTS_DIR=~/Desktop/test/PiriformLabel
reg=~/Documents/RestfMRI/SourceData/Figure_4_sourcedata/Figure_4_reg2fs.dat
wkpath=~/Documents/RestfMRI/SourceData/Figure_4_sourcedata/Stats
refbrain=/usr/local/fsl/data/standard/MNI152_T1_1mm_brain
savedir=${wkpath}/Resol1mm
[ -d ${savedir} ] || mkdir ${savedir}
for roi in Aon Tub PirF PirT; do
	for prefix in pos_Clust_1_ pos_Clust_1_tstat_; do
		flirt -in ${wkpath}/${prefix}${roi} -ref ${refbrain} -applyxfm -usesqform -interp nearestneighbour -out ${savedir}/${prefix}${roi}_1mm
		mri_vol2surf --src ${savedir}/${prefix}${roi}_1mm.nii.gz --out ${savedir}/lh.${prefix}${roi}_1mm.mgh --srcreg ${reg} --hemi lh --out_type mgh --projfrac 0.7
		mri_vol2surf --src ${savedir}/${prefix}${roi}_1mm.nii.gz --out ${savedir}/rh.${prefix}${roi}_1mm.mgh --srcreg ${reg} --hemi rh --out_type mgh --projfrac 0.7
	done
done

wkpath=~/Documents/RestfMRI/SourceData/Supplementary_Figure_2_sourcedata
refbrain=/usr/local/fsl/data/standard/MNI152_T1_1mm_brain
for fold in Aon Tub PirF PirT; do
	for vol in pos_s3_OneSampT_tfce_corrp_tstat1 neg_s3_OneSampT_tfce_corrp_tstat1; do
		flirt -in ${wkpath}/${fold}/${vol} -ref ${refbrain} -applyxfm -usesqform -interp nearestneighbour -out ${wkpath}/${fold}/${vol}_1mm
	done
done

