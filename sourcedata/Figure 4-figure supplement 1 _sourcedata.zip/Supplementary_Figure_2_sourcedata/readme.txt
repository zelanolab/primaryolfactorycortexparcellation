One-sample t test using FSL's randomize

pos_*.nii.gz: Left > Right
neg_*.nii.gz: Left < Right

